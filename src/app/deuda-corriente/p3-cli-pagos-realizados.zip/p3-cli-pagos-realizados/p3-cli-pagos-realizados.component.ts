import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {PersonService} from '../../claro-video/claroup/service/personservice';

import * as moment from 'moment';
moment.locale("es");

@Component({
  selector: 'app-p3-cli-pagos-realizados',
  templateUrl: './p3-cli-pagos-realizados.component.html',
  styleUrls: ['./p3-cli-pagos-realizados.component.css'],
    providers: [PersonService]
})
export class P3CliPagosRealizadosComponent implements OnInit {
cliente: any;
indexInvoice:number ;
currentDebtItems: any;
indexDetail:number;
selectedDetail: any;
selectedDetailInvoice: any;
payments:any;
spinStatus:boolean =true;
errorInvocation:boolean = false;
invoices: any;
  constructor(
    private router: Router, 
    private route: ActivatedRoute, 
    private personservice: PersonService
    ) {
      
    this.spinStatus =true;
 
   this.cliente = JSON.parse(localStorage.getItem('cliente'));
   //alert(this.cliente);
    this.currentDebtItems = JSON.parse(localStorage.getItem('currentDebt'));
    this.invoices = JSON.parse(localStorage.getItem('invoices'));
   if(!this.cliente) {
      console.error("No existe un cliente encontrado");
    }
    console.log(">>>Cliente encontrado: ", this.cliente);
    let detail:string = this.route.snapshot.params.detail;
    var splits = detail.split("__");
    console.log(splits[0] +"...."+splits[1]);
    this.indexInvoice = (+splits[0]);
    this.indexDetail = (+splits[1]);
    
     //this.selectedSubscription = this.cliente.subscriptions[this.indexClient];
    //console.log("****** this.selectedSubscription");
     // console.dir(this.selectedSubscription);

  
     this.selectedDetail =   this.currentDebtItems.subscriptionsList[this.indexDetail];
     this.selectedDetailInvoice = this.invoices[this.indexInvoice]
     
  }

  ngAfterViewInit() {
    console.log("=============ngAfterViewInit==============");
  }
  
  /**
   * 
   */
  ngOnInit() {
    
    this.cliente = JSON.parse(localStorage.getItem('cliente'));
   
   if(!this.cliente) {
      console.error("No existe un cliente encontrado");
    }
    console.log(">>>Cliente encontrado: ", this.cliente);
    let fechaNacimiento = "";
    if (this.cliente.personalInformation.birthday) {
        fechaNacimiento = moment(this.cliente.personalInformation.birthday).utc().format("DD MMMM YYYY")
        this.cliente.personalInformation.fechaNacimiento = fechaNacimiento;
    } else
        this.cliente.personalInformation.fechaNacimiento = "";

        
      console.log("PROBANDO SERVICIO PAYMENT ===============");
      this.spinStatus=true;  // inicia mostrando el spinner
       this.personservice.getCurrentDebtsPaymentInvoice({invoiceNo: this.selectedDetailInvoice.invoiceSn, accountCode:this.selectedDetail.contractId})
    .then(claroVideoResponse => {
    console.dir(claroVideoResponse);
    this.payments = claroVideoResponse.payments;
       var arrpayments = this.payments; 
      for (var j = 0; j < arrpayments.length; j++){
         try{
               let dou:number = arrpayments[j].paymentAmount
               dou = dou/10000000;
               arrpayments[j].paymentAmount = dou;
           }catch(error){
             console.log(error)
           }
        try{
               let dou:number = arrpayments[j].applyAmount
               dou = dou/10000000;
               arrpayments[j].applyAmount = dou;
           }catch(error){
             console.log(error)
           }
      }//fin for

    this.spinStatus=false;  // DETEN el spinner
    this.errorInvocation = false;
    //this.cliente.subscriptions[this.indexClient].selectedSubscription.subscriptionInformation.currentDebt.details[this.indexDetail];
    }).catch(errorClaroVideo => {
        console.dir(errorClaroVideo);
        this.spinStatus=true;
        this.errorInvocation = true;
      });
  
    //
  }

  verServicios(subscription: any){
    let index : any = this.cliente.subscriptions.indexOf(subscription);
    this.router.navigate(["/servicios", index]);
  }

   
    backMovimientos(){
    this.router.navigate(["/deudaClienteMovimientos",this.indexDetail]);
  }
}
