import { ComponentFixture, TestBed } from '@angular/core/testing';

import { P3CliPagosRealizadosComponent } from './p3-cli-pagos-realizados.component';

describe('P3CliPagosRealizadosComponent', () => {
  let component: P3CliPagosRealizadosComponent;
  let fixture: ComponentFixture<P3CliPagosRealizadosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ P3CliPagosRealizadosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(P3CliPagosRealizadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
